import type { SeatClass } from "../types";
import { SEAT_CLASSES } from "../types";

export const calculatePrice = (basePrice: number, seatClass: SeatClass): number => {
  const multiplier = SEAT_CLASSES[seatClass].multiplier;
  return basePrice * multiplier;
};

export const formatPrice = (price: number): string => {
  return `$${price.toLocaleString()}`;
};

export const getSeatClassColor = (seatClass: SeatClass): string => {
  const colors = {
    economy: "text-blue-600 bg-blue-50 border-blue-200",
    business: "text-purple-600 bg-purple-50 border-purple-200",
    galaxium: "text-yellow-600 bg-yellow-50 border-yellow-200"
  };
  return colors[seatClass] || colors.economy;
};

export const getSeatClassBadgeColor = (seatClass: SeatClass): string => {
  const colors = {
    economy: "bg-blue-100 text-blue-800",
    business: "bg-purple-100 text-purple-800",
    galaxium: "bg-yellow-100 text-yellow-800"
  };
  return colors[seatClass] || colors.economy;
};

export const formatDateTime = (dateTimeString: string): string => {
  const date = new Date(dateTimeString);
  return date.toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });
};

// Additional formatters for existing FlightCard component
export const formatCurrency = (amount: number): string => {
  return `$${amount.toLocaleString()}`;
};

export const formatDate = (dateString: string, format?: string): string => {
  const date = new Date(dateString);
  if (format === 'MMM dd, yyyy') {
    return date.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
  }
  return date.toLocaleDateString();
};

export const formatTime = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
};

export const calculateDuration = (departure: string, arrival: string): string => {
  const dep = new Date(departure);
  const arr = new Date(arrival);
  const diff = arr.getTime() - dep.getTime();
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  return `${hours}h ${minutes}m`;
};

// Made with Bob
