import type { Flight, SeatClass } from '../../types';
import { SEAT_CLASSES } from '../../types';
import { Card, Button } from '../common';
import { Plane, Clock } from 'lucide-react';
import { formatDate, formatTime, calculateDuration, calculatePrice, formatCurrency } from '../../utils/formatters';
import { motion } from 'framer-motion';

interface FlightCardProps {
  flight: Flight;
  onBook: (flight: Flight, seatClass: SeatClass) => void;
}

export const FlightCard = ({ flight, onBook }: FlightCardProps) => {
  const hasAnySeats = 
    flight.economy_seats > 0 || 
    flight.business_seats > 0 || 
    flight.galaxium_seats > 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="h-full flex flex-col">
        {/* Route Header */}
        <div className="flex items-center justify-between mb-4 pb-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-cosmic-gradient">
              <Plane className="text-white" size={24} />
            </div>
            <div>
              <h3 className="text-xl font-bold text-star-white">
                {flight.origin} → {flight.destination}
              </h3>
              <p className="text-sm text-star-white/60">
                Flight #{flight.flight_id}
              </p>
            </div>
          </div>
        </div>

        {/* Flight Details */}
        <div className="space-y-3 mb-4">
          {/* Departure & Arrival */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-star-white/60 mb-1">Departure</p>
              <p className="text-sm font-medium text-star-white">
                {formatDate(flight.departure_time, 'MMM dd, yyyy')}
              </p>
              <p className="text-lg font-bold text-cosmic-purple">
                {formatTime(flight.departure_time)}
              </p>
            </div>
            <div>
              <p className="text-xs text-star-white/60 mb-1">Arrival</p>
              <p className="text-sm font-medium text-star-white">
                {formatDate(flight.arrival_time, 'MMM dd, yyyy')}
              </p>
              <p className="text-lg font-bold text-cosmic-purple">
                {formatTime(flight.arrival_time)}
              </p>
            </div>
          </div>

          {/* Duration */}
          <div className="flex items-center gap-2 text-star-white/70">
            <Clock size={16} />
            <span className="text-sm">
              Duration: {calculateDuration(flight.departure_time, flight.arrival_time)}
            </span>
          </div>
        </div>

        {/* Seat Classes Section */}
        <div className="border-t border-white/10 pt-4 flex-1">
          <h4 className="text-sm font-semibold text-star-white/80 mb-3">
            Available Seat Classes
          </h4>
          <div className="space-y-2">
            {/* Economy */}
            <SeatClassRow
              seatClass="economy"
              available={flight.economy_seats}
              basePrice={flight.price}
              onBook={() => onBook(flight, "economy")}
            />
            
            {/* Business */}
            <SeatClassRow
              seatClass="business"
              available={flight.business_seats}
              basePrice={flight.price}
              onBook={() => onBook(flight, "business")}
            />
            
            {/* Galaxium */}
            <SeatClassRow
              seatClass="galaxium"
              available={flight.galaxium_seats}
              basePrice={flight.price}
              onBook={() => onBook(flight, "galaxium")}
            />
          </div>
        </div>

        {/* No Seats Warning */}
        {!hasAnySeats && (
          <div className="mt-4 bg-red-900/20 border border-red-500/30 rounded-lg p-3">
            <p className="text-red-400 text-sm font-medium text-center">
              ⚠️ No seats available on this flight
            </p>
          </div>
        )}
      </Card>
    </motion.div>
  );
};

// Helper Component for Seat Class Row
interface SeatClassRowProps {
  seatClass: SeatClass;
  available: number;
  basePrice: number;
  onBook: () => void;
}

const SeatClassRow = ({
  seatClass,
  available,
  basePrice,
  onBook,
}: SeatClassRowProps) => {
  const classInfo = SEAT_CLASSES[seatClass];
  const price = calculatePrice(basePrice, seatClass);
  const isAvailable = available > 0;
  const isLowSeats = available > 0 && available <= 2;

  return (
    <div className="flex items-center justify-between p-3 bg-space-dark/50 rounded-lg border border-white/5 hover:border-white/10 transition-colors">
      <div className="flex items-center gap-3">
        <span className="text-2xl">{classInfo.icon}</span>
        <div>
          <p className="font-semibold text-star-white">{classInfo.displayName}</p>
          <p className="text-xs text-star-white/60">{classInfo.description}</p>
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        <div className="text-right">
          <p className="font-bold text-star-white">{formatCurrency(price)}</p>
          <p className={`text-xs ${
            !isAvailable ? 'text-red-400' : 
            isLowSeats ? 'text-solar-orange' : 
            'text-alien-green'
          }`}>
            {!isAvailable ? 'Sold out' : `${available} seats`}
          </p>
        </div>
        
        <Button
          onClick={onBook}
          disabled={!isAvailable}
          size="sm"
          className="min-w-[100px]"
        >
          {isAvailable ? 'Book' : 'Unavailable'}
        </Button>
      </div>
    </div>
  );
};

// Made with Bob
