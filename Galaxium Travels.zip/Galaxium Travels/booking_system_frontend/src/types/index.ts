// API Data Models matching backend schemas

export interface Flight {
  flight_id: number;
  origin: string;
  destination: string;
  departure_time: string;
  arrival_time: string;
  price: number;  // Base price (Economy)
  economy_seats: number;
  business_seats: number;
  galaxium_seats: number;
}

export interface Booking {
  booking_id: number;
  user_id: number;
  flight_id: number;
  seat_class: string;
  status: 'booked' | 'cancelled' | 'completed';
  booking_time: string;
}

export interface User {
  user_id: number;
  name: string;
  email: string;
}

// Seat class types
export type SeatClass = "economy" | "business" | "galaxium";

export interface SeatClassInfo {
  name: string;
  displayName: string;
  multiplier: number;
  color: string;
  icon: string;
  description: string;
}

export const SEAT_CLASSES: Record<SeatClass, SeatClassInfo> = {
  economy: {
    name: "economy",
    displayName: "Economy",
    multiplier: 1,
    color: "blue",
    icon: "💺",
    description: "Standard seating with essential amenities"
  },
  business: {
    name: "business",
    displayName: "Business",
    multiplier: 2,
    color: "purple",
    icon: "🛋️",
    description: "Premium seating with enhanced comfort and service"
  },
  galaxium: {
    name: "galaxium",
    displayName: "Galaxium",
    multiplier: 3,
    color: "gold",
    icon: "⭐",
    description: "Luxury experience with exclusive amenities"
  }
};

// Request/Response types
export interface BookingRequest {
  user_id: number;
  name: string;
  flight_id: number;
  seat_class: string;
}

export interface UserRegistration {
  name: string;
  email: string;
}

export interface ErrorResponse {
  success: false;
  error: string;
  error_code: string;
  details?: string;
}

// Extended types for UI
export interface BookingWithFlight extends Booking {
  flight?: Flight;
}

export interface FlightFilters {
  origin?: string;
  destination?: string;
  minPrice?: number;
  maxPrice?: number;
  searchTerm?: string;
}

// User context type
export interface UserContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  logout: () => void;
}

// Made with Bob
