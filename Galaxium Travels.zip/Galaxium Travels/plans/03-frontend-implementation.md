# Frontend Implementation Plan for Seat Classes

## Overview
This plan details all frontend changes needed to display and interact with Economy, Business, and Galaxium seat classes.

## Implementation Order
1. Update TypeScript types
2. Update API service layer
3. Update FlightCard component (display seat classes)
4. Update BookingModal component (seat class selection)
5. Update BookingCard component (display booked class)
6. Add utility functions for pricing and formatting

## 1. TypeScript Types Update
**File**: `booking_system_frontend/src/types/index.ts`

### Update Existing Types:

```typescript
export interface Flight {
  id: number;
  origin: string;
  destination: string;
  departure_time: string;
  price: number;  // Base price (Economy)
  economy_seats: number;    // NEW
  business_seats: number;   // NEW
  galaxium_seats: number;   // NEW
  // Remove: available_seats
}

export interface Booking {
  id: number;
  user_id: number;
  flight_id: number;
  seat_class: string;  // NEW - "economy" | "business" | "galaxium"
  status: string;
}

export interface BookingRequest {
  user_id: number;
  name: string;
  flight_id: number;
  seat_class: string;  // NEW - default "economy"
}
```

### Add New Types:

```typescript
export type SeatClass = "economy" | "business" | "galaxium";

export interface SeatClassInfo {
  name: string;
  displayName: string;
  multiplier: number;
  color: string;
  icon: string;
  description: string;
}

export const SEAT_CLASSES: Record<SeatClass, SeatClassInfo> = {
  economy: {
    name: "economy",
    displayName: "Economy",
    multiplier: 1,
    color: "blue",
    icon: "💺",
    description: "Standard seating with essential amenities"
  },
  business: {
    name: "business",
    displayName: "Business",
    multiplier: 2,
    color: "purple",
    icon: "🛋️",
    description: "Premium seating with enhanced comfort and service"
  },
  galaxium: {
    name: "galaxium",
    displayName: "Galaxium",
    multiplier: 3,
    color: "gold",
    icon: "⭐",
    description: "Luxury experience with exclusive amenities"
  }
};
```

## 2. API Service Update
**File**: `booking_system_frontend/src/services/api.ts`

### Update `bookFlight` function:

```typescript
export const bookFlight = async (
  userId: number,
  name: string,
  flightId: number,
  seatClass: string = "economy"  // NEW parameter
): Promise<Booking> => {
  const response = await fetch(`${API_URL}/book`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      user_id: userId,
      name,
      flight_id: flightId,
      seat_class: seatClass  // NEW
    }),
  });

  const data = await response.json();
  if (data.success === false) {
    throw new Error(data.error || "Failed to book flight");
  }
  return data;
};
```

**Note**: Other API functions (`getFlights`, `getBookings`, `cancelBooking`) don't need changes - they automatically handle new fields.

## 3. Utility Functions
**File**: `booking_system_frontend/src/utils/formatters.ts`

### Add Price Calculation:

```typescript
import { SeatClass, SEAT_CLASSES } from "../types";

export const calculatePrice = (basePrice: number, seatClass: SeatClass): number => {
  const multiplier = SEAT_CLASSES[seatClass].multiplier;
  return basePrice * multiplier;
};

export const formatPrice = (price: number): string => {
  return `$${price.toLocaleString()}`;
};

export const getSeatClassColor = (seatClass: SeatClass): string => {
  const colors = {
    economy: "text-blue-600 bg-blue-50 border-blue-200",
    business: "text-purple-600 bg-purple-50 border-purple-200",
    galaxium: "text-yellow-600 bg-yellow-50 border-yellow-200"
  };
  return colors[seatClass] || colors.economy;
};

export const getSeatClassBadgeColor = (seatClass: SeatClass): string => {
  const colors = {
    economy: "bg-blue-100 text-blue-800",
    business: "bg-purple-100 text-purple-800",
    galaxium: "bg-yellow-100 text-yellow-800"
  };
  return colors[seatClass] || colors.economy;
};
```

## 4. FlightCard Component Update
**File**: `booking_system_frontend/src/components/flights/FlightCard.tsx`

### Display Seat Availability by Class:

```tsx
import { Flight, SEAT_CLASSES, SeatClass } from "../../types";
import { calculatePrice, formatPrice } from "../../utils/formatters";

interface FlightCardProps {
  flight: Flight;
  onBook: (flightId: number, seatClass: SeatClass) => void;
}

export const FlightCard: React.FC<FlightCardProps> = ({ flight, onBook }) => {
  const hasAnySeats = 
    flight.economy_seats > 0 || 
    flight.business_seats > 0 || 
    flight.galaxium_seats > 0;

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <div className="space-y-4">
        {/* Flight Info Section */}
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-xl font-bold text-gray-900">
              {flight.origin} → {flight.destination}
            </h3>
            <p className="text-gray-600 mt-1">
              🚀 {formatDateTime(flight.departure_time)}
            </p>
          </div>
        </div>

        {/* Seat Classes Section */}
        <div className="border-t pt-4">
          <h4 className="text-sm font-semibold text-gray-700 mb-3">
            Available Seat Classes
          </h4>
          <div className="space-y-2">
            {/* Economy */}
            <SeatClassRow
              seatClass="economy"
              available={flight.economy_seats}
              basePrice={flight.price}
              onBook={() => onBook(flight.id, "economy")}
            />
            
            {/* Business */}
            <SeatClassRow
              seatClass="business"
              available={flight.business_seats}
              basePrice={flight.price}
              onBook={() => onBook(flight.id, "business")}
            />
            
            {/* Galaxium */}
            <SeatClassRow
              seatClass="galaxium"
              available={flight.galaxium_seats}
              basePrice={flight.price}
              onBook={() => onBook(flight.id, "galaxium")}
            />
          </div>
        </div>

        {/* No Seats Warning */}
        {!hasAnySeats && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3">
            <p className="text-red-800 text-sm font-medium">
              ⚠️ No seats available on this flight
            </p>
          </div>
        )}
      </div>
    </Card>
  );
};

// Helper Component for Seat Class Row
interface SeatClassRowProps {
  seatClass: SeatClass;
  available: number;
  basePrice: number;
  onBook: () => void;
}

const SeatClassRow: React.FC<SeatClassRowProps> = ({
  seatClass,
  available,
  basePrice,
  onBook,
}) => {
  const classInfo = SEAT_CLASSES[seatClass];
  const price = calculatePrice(basePrice, seatClass);
  const isAvailable = available > 0;

  return (
    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
      <div className="flex items-center gap-3">
        <span className="text-2xl">{classInfo.icon}</span>
        <div>
          <p className="font-semibold text-gray-900">{classInfo.displayName}</p>
          <p className="text-xs text-gray-600">{classInfo.description}</p>
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        <div className="text-right">
          <p className="font-bold text-gray-900">{formatPrice(price)}</p>
          <p className={`text-xs ${isAvailable ? "text-green-600" : "text-red-600"}`}>
            {isAvailable ? `${available} seats` : "Sold out"}
          </p>
        </div>
        
        <Button
          onClick={onBook}
          disabled={!isAvailable}
          variant={isAvailable ? "primary" : "secondary"}
          size="sm"
        >
          {isAvailable ? "Book" : "Unavailable"}
        </Button>
      </div>
    </div>
  );
};
```

## 5. BookingModal Component Update
**File**: `booking_system_frontend/src/components/bookings/BookingModal.tsx`

### Add Seat Class Selection:

```tsx
import { useState } from "react";
import { Flight, SeatClass, SEAT_CLASSES } from "../../types";
import { calculatePrice, formatPrice, getSeatClassColor } from "../../utils/formatters";

interface BookingModalProps {
  flight: Flight;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (seatClass: SeatClass) => void;
  initialSeatClass?: SeatClass;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  flight,
  isOpen,
  onClose,
  onConfirm,
  initialSeatClass = "economy",
}) => {
  const [selectedClass, setSelectedClass] = useState<SeatClass>(initialSeatClass);
  const selectedPrice = calculatePrice(flight.price, selectedClass);

  if (!isOpen) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Confirm Booking">
      <div className="space-y-6">
        {/* Flight Details */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="font-semibold text-gray-900 mb-2">Flight Details</h3>
          <p className="text-gray-700">
            {flight.origin} → {flight.destination}
          </p>
          <p className="text-gray-600 text-sm">
            {formatDateTime(flight.departure_time)}
          </p>
        </div>

        {/* Seat Class Selection */}
        <div>
          <h3 className="font-semibold text-gray-900 mb-3">Select Seat Class</h3>
          <div className="space-y-2">
            {(["economy", "business", "galaxium"] as SeatClass[]).map((seatClass) => {
              const classInfo = SEAT_CLASSES[seatClass];
              const price = calculatePrice(flight.price, seatClass);
              const available = flight[`${seatClass}_seats`];
              const isAvailable = available > 0;
              const isSelected = selectedClass === seatClass;

              return (
                <button
                  key={seatClass}
                  onClick={() => isAvailable && setSelectedClass(seatClass)}
                  disabled={!isAvailable}
                  className={`
                    w-full p-4 rounded-lg border-2 text-left transition-all
                    ${isSelected ? getSeatClassColor(seatClass) : "border-gray-200 bg-white"}
                    ${!isAvailable ? "opacity-50 cursor-not-allowed" : "hover:border-gray-300 cursor-pointer"}
                  `}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{classInfo.icon}</span>
                      <div>
                        <p className="font-semibold">{classInfo.displayName}</p>
                        <p className="text-sm text-gray-600">{classInfo.description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">{formatPrice(price)}</p>
                      <p className={`text-xs ${isAvailable ? "text-green-600" : "text-red-600"}`}>
                        {isAvailable ? `${available} left` : "Sold out"}
                      </p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Price Summary */}
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <div className="flex justify-between items-center">
            <span className="font-semibold text-gray-900">Total Price:</span>
            <span className="text-2xl font-bold text-blue-600">
              {formatPrice(selectedPrice)}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Button onClick={onClose} variant="secondary" className="flex-1">
            Cancel
          </Button>
          <Button
            onClick={() => onConfirm(selectedClass)}
            variant="primary"
            className="flex-1"
          >
            Confirm Booking
          </Button>
        </div>
      </div>
    </Modal>
  );
};
```

## 6. BookingCard Component Update
**File**: `booking_system_frontend/src/components/bookings/BookingCard.tsx`

### Display Booked Seat Class:

```tsx
import { Booking, SEAT_CLASSES, SeatClass } from "../../types";
import { getSeatClassBadgeColor } from "../../utils/formatters";

interface BookingCardProps {
  booking: Booking;
  flight: Flight;
  onCancel: (bookingId: number) => void;
}

export const BookingCard: React.FC<BookingCardProps> = ({
  booking,
  flight,
  onCancel,
}) => {
  const seatClass = booking.seat_class as SeatClass;
  const classInfo = SEAT_CLASSES[seatClass];
  const price = calculatePrice(flight.price, seatClass);

  return (
    <Card>
      <div className="space-y-4">
        {/* Header with Status and Class */}
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-xl font-bold text-gray-900">
              {flight.origin} → {flight.destination}
            </h3>
            <p className="text-gray-600 mt-1">
              🚀 {formatDateTime(flight.departure_time)}
            </p>
          </div>
          <div className="flex flex-col items-end gap-2">
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${
              booking.status === "booked" 
                ? "bg-green-100 text-green-800"
                : "bg-gray-100 text-gray-800"
            }`}>
              {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
            </span>
          </div>
        </div>

        {/* Seat Class Badge */}
        <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
          <span className="text-xl">{classInfo.icon}</span>
          <div className="flex-1">
            <p className="text-sm text-gray-600">Seat Class</p>
            <p className="font-semibold text-gray-900">{classInfo.displayName}</p>
          </div>
          <span className="font-bold text-lg">{formatPrice(price)}</span>
        </div>

        {/* Booking Details */}
        <div className="text-sm text-gray-600 space-y-1">
          <p>Booking ID: #{booking.id}</p>
          <p>Flight ID: #{booking.flight_id}</p>
        </div>

        {/* Cancel Button */}
        {booking.status === "booked" && (
          <Button
            onClick={() => onCancel(booking.id)}
            variant="danger"
            className="w-full"
          >
            Cancel Booking
          </Button>
        )}
      </div>
    </Card>
  );
};
```

## 7. Flights Page Update
**File**: `booking_system_frontend/src/pages/Flights.tsx`

### Update Booking Flow:

```tsx
import { useState } from "react";
import { Flight, SeatClass } from "../types";
import { bookFlight } from "../services/api";

export const Flights: React.FC = () => {
  const [selectedFlight, setSelectedFlight] = useState<Flight | null>(null);
  const [selectedSeatClass, setSelectedSeatClass] = useState<SeatClass>("economy");
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleBookClick = (flightId: number, seatClass: SeatClass) => {
    const flight = flights.find(f => f.id === flightId);
    if (flight) {
      setSelectedFlight(flight);
      setSelectedSeatClass(seatClass);
      setIsModalOpen(true);
    }
  };

  const handleConfirmBooking = async (seatClass: SeatClass) => {
    if (!selectedFlight || !user) return;

    try {
      setIsLoading(true);
      await bookFlight(user.id, user.name, selectedFlight.id, seatClass);
      setIsModalOpen(false);
      // Refresh flights to update seat counts
      await fetchFlights();
      // Show success message
    } catch (error) {
      console.error("Booking failed:", error);
      // Show error message
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      {/* Flight Cards */}
      {flights.map((flight) => (
        <FlightCard
          key={flight.id}
          flight={flight}
          onBook={handleBookClick}
        />
      ))}

      {/* Booking Modal */}
      {selectedFlight && (
        <BookingModal
          flight={selectedFlight}
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onConfirm={handleConfirmBooking}
          initialSeatClass={selectedSeatClass}
        />
      )}
    </div>
  );
};
```

## 8. Styling Enhancements
**File**: `booking_system_frontend/src/index.css` or component styles

### Add Seat Class Theme Colors:

```css
/* Seat Class Colors */
.seat-economy {
  @apply bg-blue-50 border-blue-200 text-blue-800;
}

.seat-business {
  @apply bg-purple-50 border-purple-200 text-purple-800;
}

.seat-galaxium {
  @apply bg-yellow-50 border-yellow-200 text-yellow-800;
}

/* Seat Class Badges */
.badge-economy {
  @apply bg-blue-100 text-blue-800 border-blue-300;
}

.badge-business {
  @apply bg-purple-100 text-purple-800 border-purple-300;
}

.badge-galaxium {
  @apply bg-yellow-100 text-yellow-800 border-yellow-300;
}
```

## Implementation Checklist

- [ ] Update Flight interface in types/index.ts
- [ ] Update Booking interface in types/index.ts
- [ ] Add SeatClass type and SEAT_CLASSES constant
- [ ] Update bookFlight API function with seat_class parameter
- [ ] Add price calculation utilities in formatters.ts
- [ ] Add seat class color utilities in formatters.ts
- [ ] Update FlightCard to display all seat classes
- [ ] Create SeatClassRow component
- [ ] Update BookingModal for seat class selection
- [ ] Update BookingCard to display booked class
- [ ] Update Flights page booking flow
- [ ] Add seat class styling to CSS
- [ ] Test booking flow for all three classes
- [ ] Test seat availability updates after booking
- [ ] Test cancellation restores correct seat count
- [ ] Verify responsive design on mobile

## User Experience Flow

1. **Browse Flights**: User sees all three seat classes with availability and pricing
2. **Select Class**: User clicks "Book" on their preferred class
3. **Confirm Booking**: Modal shows selected class with price breakdown
4. **View Bookings**: My Bookings page shows seat class badge and price
5. **Cancel Booking**: Cancellation restores seats to correct class

## Visual Design Guidelines

- **Economy**: Blue theme (💺) - Standard, accessible
- **Business**: Purple theme (🛋️) - Premium, professional
- **Galaxium**: Gold/Yellow theme (⭐) - Luxury, exclusive
- Use icons consistently across all components
- Show clear availability indicators (green for available, red for sold out)
- Display price prominently with proper formatting
- Use badges to highlight seat class in bookings

## Error Handling

- Show error if invalid seat class selected
- Display "Sold out" for unavailable classes
- Disable booking button when no seats available
- Show clear error messages for booking failures
- Refresh flight data after successful booking

## Testing Scenarios

1. Book each seat class type
2. Verify price calculations are correct
3. Test booking when class is sold out
4. Verify seat counts update after booking
5. Test cancellation restores correct class
6. Check responsive design on mobile
7. Verify all three classes display correctly
8. Test rapid booking (race conditions)