# Database Schema Changes for Seat Classes

## Overview
This plan outlines the database schema modifications needed to support three seat classes: Economy, Business, and Galaxium.

## Current State Analysis
- **Flight Model**: Currently has a single `available_seats` field (Integer)
- **Booking Model**: Links user to flight but doesn't track seat class
- **Limitation**: No way to differentiate seat types or pricing

## Proposed Schema Changes

### 1. Flight Model Modifications
**File**: `booking_system_backend/models.py`

Replace single `available_seats` field with class-specific fields:

```python
class Flight(Base):
    __tablename__ = "flights"
    
    id = Column(Integer, primary_key=True, index=True)
    origin = Column(String, nullable=False)
    destination = Column(String, nullable=False)
    departure_time = Column(String, nullable=False)
    price = Column(Integer, nullable=False)  # Base price (Economy)
    
    # Seat availability by class
    economy_seats = Column(Integer, nullable=False, default=100)
    business_seats = Column(Integer, nullable=False, default=30)
    galaxium_seats = Column(Integer, nullable=False, default=10)
    
    bookings = relationship("Booking", back_populates="flight")
```

**Rationale**:
- Separate seat counts allow independent tracking per class
- Default values: Economy (100), Business (30), Galaxium (10)
- Base price represents Economy class pricing

### 2. Booking Model Modifications
**File**: `booking_system_backend/models.py`

Add `seat_class` field to track which class was booked:

```python
class Booking(Base):
    __tablename__ = "bookings"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    flight_id = Column(Integer, ForeignKey("flights.id"), nullable=False)
    seat_class = Column(String, nullable=False, default="economy")  # NEW
    status = Column(String, nullable=False, default="booked")
    
    user = relationship("User", back_populates="bookings")
    flight = relationship("Flight", back_populates="bookings")
```

**Valid Values**: "economy", "business", "galaxium"

### 3. Pricing Strategy
Store base price in Flight model, calculate class-specific pricing:
- **Economy**: base_price (1x)
- **Business**: base_price × 2 (2x)
- **Galaxium**: base_price × 3 (3x)

Pricing multipliers will be handled in service layer, not stored in database.

## Migration Strategy

### Option A: Database Recreation (Recommended for Development)
1. Delete existing `galaxium.db` file
2. Update models.py with new schema
3. Run server.py - will auto-create tables with new schema
4. Seed data will populate with new structure

### Option B: SQLAlchemy Migration (Production)
1. Install Alembic: `pip install alembic`
2. Initialize: `alembic init alembic`
3. Create migration script
4. Apply migration: `alembic upgrade head`

**For this project, Option A is sufficient** since we're in development phase.

## Seed Data Updates
**File**: `booking_system_backend/seed.py`

Update flight creation to include class-specific seats:

```python
flights = [
    Flight(
        origin="Earth",
        destination="Mars",
        departure_time="2026-06-01 10:00",
        price=500,
        economy_seats=100,
        business_seats=30,
        galaxium_seats=10
    ),
    # ... more flights
]
```

## Data Validation Rules
1. **Seat counts must be non-negative**: Enforce in service layer
2. **Seat class must be valid**: Only "economy", "business", "galaxium"
3. **Booking requires available seats**: Check class-specific availability
4. **Cancellation restores seats**: Increment correct class counter

## Impact Assessment
- **Breaking Change**: Yes - existing bookings won't have seat_class
- **Data Loss**: Existing database must be recreated or migrated
- **Backward Compatibility**: None - API changes required
- **Testing Impact**: All tests need updating for new schema

## Next Steps
After schema changes:
1. Update Pydantic schemas (schemas.py)
2. Update service layer logic (services/)
3. Update REST endpoints (server.py)
4. Update MCP tools (server.py)
5. Update frontend types and UI