# Backend Implementation Plan for Seat Classes

## Overview
This plan details all backend code changes needed to support Economy, Business, and Galaxium seat classes.

## Implementation Order
Changes must follow this sequence due to architectural constraints:
1. Update models.py (database schema)
2. Update schemas.py (API contracts)
3. Update service layer (business logic)
4. Update server.py (endpoints and MCP tools)
5. Update tests

## 1. Models Update
**File**: `booking_system_backend/models.py`

### Changes Required:
```python
# Flight model - replace available_seats with class-specific fields
class Flight(Base):
    # ... existing fields ...
    economy_seats = Column(Integer, nullable=False, default=100)
    business_seats = Column(Integer, nullable=False, default=30)
    galaxium_seats = Column(Integer, nullable=False, default=10)
    # Remove: available_seats

# Booking model - add seat_class field
class Booking(Base):
    # ... existing fields ...
    seat_class = Column(String, nullable=False, default="economy")
```

## 2. Schemas Update
**File**: `booking_system_backend/schemas.py`

### New/Modified Schemas:

```python
class FlightOut(BaseModel):
    id: int
    origin: str
    destination: str
    departure_time: str
    price: int  # Base price (Economy)
    economy_seats: int
    business_seats: int
    galaxium_seats: int
    
    class Config:
        from_attributes = True

class BookingRequest(BaseModel):
    user_id: int
    name: str
    flight_id: int
    seat_class: str = "economy"  # NEW - default to economy

class BookingOut(BaseModel):
    id: int
    user_id: int
    flight_id: int
    seat_class: str  # NEW
    status: str
    
    class Config:
        from_attributes = True
```

### Validation Helper:
```python
VALID_SEAT_CLASSES = ["economy", "business", "galaxium"]

def validate_seat_class(seat_class: str) -> bool:
    return seat_class.lower() in VALID_SEAT_CLASSES
```

## 3. Service Layer Updates

### 3.1 Flight Service
**File**: `booking_system_backend/services/flight.py`

**Current**: Returns flights with `available_seats`
**New**: Returns flights with class-specific seat counts

```python
def list_flights(db: Session) -> list[Flight]:
    """List all flights with class-specific seat availability."""
    return db.query(Flight).all()
```

**Note**: No logic change needed - schema handles the new fields automatically.

### 3.2 Booking Service
**File**: `booking_system_backend/services/booking.py`

#### Key Changes:

**A. Update `book_flight` function signature:**
```python
def book_flight(
    db: Session, 
    user_id: int, 
    name: str, 
    flight_id: int,
    seat_class: str = "economy"  # NEW parameter
) -> Union[Booking, ErrorResponse]:
```

**B. Add seat class validation:**
```python
# Validate seat class
seat_class = seat_class.lower()
if seat_class not in ["economy", "business", "galaxium"]:
    return ErrorResponse(
        success=False,
        error="Invalid seat class",
        details=f"Seat class must be economy, business, or galaxium"
    )
```

**C. Update seat availability check:**
```python
# Check class-specific seat availability
if seat_class == "economy":
    if flight.economy_seats <= 0:
        return ErrorResponse(
            success=False,
            error="No economy seats available",
            details=f"Flight {flight_id} has no economy seats"
        )
    flight.economy_seats -= 1
elif seat_class == "business":
    if flight.business_seats <= 0:
        return ErrorResponse(
            success=False,
            error="No business seats available",
            details=f"Flight {flight_id} has no business seats"
        )
    flight.business_seats -= 1
elif seat_class == "galaxium":
    if flight.galaxium_seats <= 0:
        return ErrorResponse(
            success=False,
            error="No galaxium seats available",
            details=f"Flight {flight_id} has no galaxium seats"
        )
    flight.galaxium_seats -= 1
```

**D. Create booking with seat class:**
```python
booking = Booking(
    user_id=user_id,
    flight_id=flight_id,
    seat_class=seat_class,  # NEW
    status="booked"
)
```

**E. Update `cancel_booking` to restore correct seat count:**
```python
def cancel_booking(db: Session, booking_id: int) -> Union[Booking, ErrorResponse]:
    # ... existing validation ...
    
    # Restore seat to correct class
    flight = booking.flight
    if booking.seat_class == "economy":
        flight.economy_seats += 1
    elif booking.seat_class == "business":
        flight.business_seats += 1
    elif booking.seat_class == "galaxium":
        flight.galaxium_seats += 1
    
    booking.status = "cancelled"
    db.commit()
    db.refresh(booking)
    return booking
```

## 4. Server Endpoints Update
**File**: `booking_system_backend/server.py`

### 4.1 MCP Tools Updates

**A. Update `book_flight` tool:**
```python
@mcp.tool()
def book_flight(
    user_id: int, 
    name: str, 
    flight_id: int,
    seat_class: str = "economy"  # NEW parameter
) -> BookingOut:
    """Book a seat on a specific flight for a user.
    
    Args:
        user_id: The user's ID
        name: The user's name (must match registered name)
        flight_id: The flight ID to book
        seat_class: Seat class - economy, business, or galaxium (default: economy)
    """
    db = SessionLocal()
    try:
        result = booking_service.book_flight(
            db, user_id, name, flight_id, seat_class
        )
        if isinstance(result, ErrorResponse):
            raise Exception(result.details or result.error)
        return BookingOut.model_validate(result)
    finally:
        db.close()
```

**B. `list_flights` tool:**
No changes needed - automatically returns new fields.

**C. `get_bookings` tool:**
No changes needed - automatically returns seat_class field.

**D. `cancel_booking` tool:**
No changes needed - service layer handles seat restoration.

### 4.2 REST Endpoints Updates

**A. Update POST /book endpoint:**
```python
@app.post("/book", response_model=Union[BookingOut, ErrorResponse], tags=["Bookings"])
def book_flight_endpoint(request: BookingRequest, db: Session = Depends(get_db)):
    result = booking_service.book_flight(
        db, 
        request.user_id, 
        request.name, 
        request.flight_id,
        request.seat_class  # NEW - pass seat class
    )
    if isinstance(result, ErrorResponse):
        return result
    return BookingOut.model_validate(result)
```

**B. GET /flights endpoint:**
No changes needed - automatically returns new fields.

**C. GET /bookings/{user_id} endpoint:**
No changes needed - automatically returns seat_class field.

**D. POST /cancel/{booking_id} endpoint:**
No changes needed - service layer handles restoration.

## 5. Seed Data Update
**File**: `booking_system_backend/seed.py`

Update flight creation:
```python
flights = [
    Flight(
        origin="Earth",
        destination="Mars",
        departure_time="2026-06-01 10:00",
        price=500,
        economy_seats=100,
        business_seats=30,
        galaxium_seats=10
    ),
    Flight(
        origin="Mars",
        destination="Jupiter",
        departure_time="2026-06-15 14:30",
        price=1200,
        economy_seats=80,
        business_seats=25,
        galaxium_seats=8
    ),
    # ... more flights
]
```

## 6. Testing Updates
**File**: `booking_system_backend/tests/test_services.py`

### Required Test Updates:

**A. Update flight fixtures:**
```python
@pytest.fixture
def sample_flight(db):
    flight = Flight(
        origin="Earth",
        destination="Mars",
        departure_time="2026-06-01 10:00",
        price=500,
        economy_seats=100,
        business_seats=30,
        galaxium_seats=10
    )
    db.add(flight)
    db.commit()
    db.refresh(flight)
    return flight
```

**B. Add seat class tests:**
```python
def test_book_flight_economy(db, sample_user, sample_flight):
    result = book_flight(db, sample_user.id, sample_user.name, sample_flight.id, "economy")
    assert isinstance(result, Booking)
    assert result.seat_class == "economy"
    assert sample_flight.economy_seats == 99

def test_book_flight_business(db, sample_user, sample_flight):
    result = book_flight(db, sample_user.id, sample_user.name, sample_flight.id, "business")
    assert isinstance(result, Booking)
    assert result.seat_class == "business"
    assert sample_flight.business_seats == 29

def test_book_flight_invalid_class(db, sample_user, sample_flight):
    result = book_flight(db, sample_user.id, sample_user.name, sample_flight.id, "first")
    assert isinstance(result, ErrorResponse)
    assert "Invalid seat class" in result.error

def test_book_flight_no_seats_available(db, sample_user, sample_flight):
    sample_flight.galaxium_seats = 0
    db.commit()
    result = book_flight(db, sample_user.id, sample_user.name, sample_flight.id, "galaxium")
    assert isinstance(result, ErrorResponse)
    assert "No galaxium seats available" in result.error

def test_cancel_booking_restores_correct_class(db, sample_user, sample_flight):
    # Book business class
    booking = book_flight(db, sample_user.id, sample_user.name, sample_flight.id, "business")
    initial_business = sample_flight.business_seats
    
    # Cancel booking
    result = cancel_booking(db, booking.id)
    assert isinstance(result, Booking)
    assert sample_flight.business_seats == initial_business + 1
```

## 7. Price Calculation Helper
**File**: `booking_system_backend/services/booking.py` or new `utils.py`

```python
def calculate_price(base_price: int, seat_class: str) -> int:
    """Calculate price based on seat class.
    
    Args:
        base_price: Base price (Economy price)
        seat_class: Seat class (economy/business/galaxium)
    
    Returns:
        Calculated price for the seat class
    """
    multipliers = {
        "economy": 1,
        "business": 2,
        "galaxium": 3
    }
    return base_price * multipliers.get(seat_class.lower(), 1)
```

**Note**: Price calculation can be added to frontend or returned in API response.

## Implementation Checklist

- [ ] Update Flight model with class-specific seat fields
- [ ] Update Booking model with seat_class field
- [ ] Delete old database file (galaxium.db)
- [ ] Update FlightOut schema
- [ ] Update BookingRequest schema with seat_class
- [ ] Update BookingOut schema with seat_class
- [ ] Update book_flight service function
- [ ] Update cancel_booking service function
- [ ] Update book_flight MCP tool
- [ ] Update book_flight REST endpoint
- [ ] Update seed.py with new flight structure
- [ ] Update all test fixtures
- [ ] Add new seat class tests
- [ ] Run tests to verify: `cd booking_system_backend && pytest`
- [ ] Start server to verify: `cd booking_system_backend && python server.py`

## Critical Notes

1. **Database must be recreated** - Delete `galaxium.db` before first run
2. **MCP created before FastAPI** - Maintain existing server.py structure
3. **Service layer returns Union types** - Always check ErrorResponse
4. **Seats decremented immediately** - No rollback on partial failure
5. **Test both SessionLocal instances** - Patch `db.SessionLocal` and `server.SessionLocal`