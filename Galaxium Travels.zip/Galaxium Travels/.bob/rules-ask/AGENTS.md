# Ask Mode Rules (Non-Obvious Only)

This file contains project-specific documentation context discovered by reading the codebase.

## Project Organization (Counterintuitive)

- **Backend and frontend are separate directories** - Not a monorepo with shared packages
- **Commands must run from specific directories** - Backend: `cd booking_system_backend`, Frontend: `cd booking_system_frontend`
- **Two separate servers** - Backend on port 8080, Frontend on port 5173 (not a single unified server)

## Dual Protocol Architecture

- **Backend serves TWO protocols simultaneously** - REST API (FastAPI) AND MCP protocol (FastMCP)
- **MCP is mounted at /mcp** - Not a separate server, integrated into FastAPI app
- **Different session patterns** - MCP tools use SessionLocal() directly, REST uses dependency injection

## Testing Context

- **Tests require directory context** - Must run from `booking_system_backend` directory
- **sys.path manipulation required** - Tests use `sys.path.insert(0)` to import from parent
- **In-memory database for tests** - Uses `:memory:` SQLite with StaticPool (not file-based)
- **seed() is disabled in tests** - Monkeypatched to prevent data pollution

## Frontend Architecture

- **Vite-specific env variables** - Uses `import.meta.env.VITE_API_URL` (not process.env)
- **localStorage for user persistence** - Key is 'galaxium_user' (not session-based)
- **Error detection pattern** - Check `response.success === false` (not response.error)

## Service Layer Pattern

- **Services return Union types** - All return `Result | ErrorResponse` (not exceptions)
- **ErrorResponse is an object** - Not an exception, must check `isinstance(result, ErrorResponse)`
- **MCP tools convert to exceptions** - They raise Exception(result.details or result.error)

## Database Constraints

- **Booking requires name validation** - Checks both user_id AND name match (not just user_id)
- **Seats decremented immediately** - No transaction rollback on booking failure
- **Status is string** - "booked", "cancelled", "completed" (not enum type)

## API Documentation

- **Swagger UI available** - At http://localhost:8080/docs (FastAPI auto-generated)
- **MCP endpoint** - At http://localhost:8080/mcp (for AI agents)
- **Health check** - At http://localhost:8080/ (returns {"status": "OK"})