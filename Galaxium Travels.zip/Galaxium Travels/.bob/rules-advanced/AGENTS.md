# Advanced Mode Rules (Non-Obvious Only)

This file contains project-specific advanced coding rules discovered by reading the codebase.

## Backend Service Layer Pattern

- **Services return Union[Result, ErrorResponse]** - Never raise exceptions, always return ErrorResponse objects
- **Check isinstance(result, ErrorResponse)** before using service results in endpoints
- **MCP tools must convert ErrorResponse to Exception** - Pattern: `raise Exception(result.details or result.error)`
- **SessionLocal() pattern differs** - MCP tools create/close sessions manually, REST uses get_db() dependency

## Database Session Management

- **MCP tools pattern**:
  ```python
  db = SessionLocal()
  try:
      result = service_function(db, ...)
      if isinstance(result, ErrorResponse):
          raise Exception(result.details or result.error)
      return result
  finally:
      db.close()
  ```

- **REST endpoints pattern**:
  ```python
  def endpoint(db: Session = Depends(get_db)):
      return service_function(db, ...)
  ```

## Critical Ordering

- **MCP server MUST be created before FastAPI app** - Required for lifespan combination in server.py
- **Pattern**: Create `mcp = FastMCP()`, define tools, create `mcp_app = mcp.http_app()`, THEN create FastAPI app

## Validation Rules

- **book_flight requires BOTH user_id AND name** - Validates name matches user_id (not just user_id exists)
- **Status values are strings** - Use "booked", "cancelled", "completed" (not enums)
- **Seats decremented immediately** - No rollback if booking fails after seat decrement

## Frontend API Integration

- **Error detection**: Check `response.success === false` (not response.error)
- **Types use snake_case** - Match Python backend: flight_id, user_id, booking_id
- **API base URL**: Use `import.meta.env.VITE_API_URL` (Vite-specific, not process.env)
- **localStorage key**: 'galaxium_user' for user persistence

## Testing Patterns

- **sys.path.insert(0)** required in conftest.py and test files to import from parent directory
- **Monkeypatch both SessionLocal instances**: Patch `db.SessionLocal` AND `server.SessionLocal` separately
- **Disable seed()**: Monkeypatch to `lambda: None` to prevent test data pollution
- **Use StaticPool**: In-memory SQLite requires StaticPool for thread safety

## MCP Integration

- **MCP endpoint**: Available at `/mcp` path on main server (port 8080)
- **MCP tools are synchronous** - Use SessionLocal() directly, not async patterns
- **Tool error handling**: Convert ErrorResponse to Exception for MCP protocol compliance