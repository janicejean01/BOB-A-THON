# Plan Mode Rules (Non-Obvious Only)

This file contains project-specific architectural constraints discovered by reading the codebase.

## Critical Architecture Constraints

- **MCP server MUST be created before FastAPI app** - Required for proper lifespan combination in server.py
- **Creation order**: `mcp = FastMCP()` → define tools → `mcp_app = mcp.http_app()` → create FastAPI app → mount MCP
- **Breaking this order causes lifespan conflicts** - FastAPI won't properly initialize database

## Service Layer Architecture

- **Services never raise exceptions** - Always return Union[Result, ErrorResponse]
- **Two different session patterns coexist**:
  - MCP tools: Manual SessionLocal() creation/cleanup
  - REST endpoints: Dependency injection with get_db()
- **This is intentional** - MCP protocol requires synchronous patterns, REST uses FastAPI patterns

## Database Transaction Model

- **Seats are decremented immediately** - No rollback mechanism if booking fails after decrement
- **This is by design** - Prevents race conditions but means partial failures leave inconsistent state
- **Booking validation happens BEFORE seat decrement** - Critical ordering to minimize inconsistency

## Testing Architecture

- **Tests use in-memory SQLite with StaticPool** - Required for thread safety in test environment
- **Two SessionLocal instances must be patched** - Both `db.SessionLocal` and `server.SessionLocal`
- **seed() must be disabled** - Monkeypatched to lambda: None to prevent test data pollution
- **sys.path manipulation required** - Tests can't import without `sys.path.insert(0)`

## Frontend-Backend Coupling

- **Types use snake_case** - Frontend TypeScript types match Python backend exactly (flight_id, not flightId)
- **Error detection pattern is non-standard** - Check `success === false` (not checking for error field)
- **localStorage is the user session mechanism** - No JWT, cookies, or server-side sessions

## Validation Architecture

- **book_flight validates BOTH user_id AND name** - Not just user_id existence
- **This prevents user impersonation** - Name must match the user_id's registered name
- **Status is stored as string** - "booked", "cancelled", "completed" (not enum or integer)

## Deployment Constraints

- **Backend must run from booking_system_backend directory** - Database path is relative
- **Frontend must run from booking_system_frontend directory** - Vite config expects this
- **Two separate processes required** - Backend (port 8080) and Frontend (port 5173)
- **CORS is wide open** - allow_origins=["*"] for development (should be restricted in production)