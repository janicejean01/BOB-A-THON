# 🚀 Galaxium Travels - Interplanetary Booking System

A complete full-stack application for booking interplanetary space travel, featuring a modern React frontend and a FastAPI backend with dual REST and MCP (Model Context Protocol) support.

## 🌟 Features

- **Modern Space-Themed UI** - Beautiful, responsive interface with animated starfield
- **Full Booking System** - Browse flights, make bookings, manage reservations
- **Dual Protocol Backend** - REST API and MCP (Model Context Protocol) support
- **Type-Safe** - Full TypeScript frontend and Python type hints
- **Real-Time Updates** - Live flight availability and booking status
- **User Management** - Simple name/email authentication
- **Production Ready** - Optimized builds and comprehensive error handling

## 🏗️ Architecture

```
Galaxium Travels/
├── booking_system_backend/     # FastAPI + FastMCP backend (Python)
│   ├── server.py              # Main server (REST & MCP on port 8080)
│   ├── services/              # Business logic layer
│   │   ├── booking.py         # Booking operations
│   │   ├── flight.py          # Flight operations
│   │   └── user.py            # User operations
│   ├── models.py              # SQLAlchemy ORM models
│   ├── schemas.py             # Pydantic validation schemas
│   ├── db.py                  # Database configuration
│   ├── seed.py                # Demo data seeding
│   ├── tests/                 # Test suite (pytest)
│   │   ├── conftest.py        # Test configuration
│   │   ├── test_services.py   # Service layer tests
│   │   └── test_rest.py       # REST API tests
│   ├── requirements.txt       # Python dependencies
│   └── Dockerfile             # Container configuration
│
├── booking_system_frontend/    # React + TypeScript frontend
│   ├── src/
│   │   ├── components/        # Reusable UI components
│   │   │   ├── common/        # Button, Card, Modal, etc.
│   │   │   ├── layout/        # Header, Footer, Layout
│   │   │   ├── flights/       # FlightCard
│   │   │   ├── bookings/      # BookingCard, BookingModal
│   │   │   └── user/          # UserIdentification
│   │   ├── pages/             # Route pages
│   │   │   ├── Home.tsx       # Landing page
│   │   │   ├── Flights.tsx    # Browse flights
│   │   │   └── MyBookings.tsx # Manage bookings
│   │   ├── services/          # API integration (Axios)
│   │   ├── types/             # TypeScript definitions
│   │   ├── hooks/             # Custom React hooks
│   │   └── utils/             # Helper functions
│   ├── dist/                  # Production build output
│   ├── package.json           # Node dependencies
│   └── vite.config.ts         # Vite configuration
│
├── .bob/                      # Bob AI agent rules
│   └── rules-code/            # Code-specific guidelines
├── plans/                     # Implementation plans
├── AGENTS.md                  # Agent guidance documentation
├── start.sh                   # Unix/Mac startup script
└── start.bat                  # Windows startup script
```

## 🚀 Quick Start

### Prerequisites

- **Python 3.8+** - [Download](https://www.python.org/downloads/)
- **Node.js 18+** - [Download](https://nodejs.org/)
- **npm** (comes with Node.js)

### Option 1: One-Command Start (Recommended)

#### On macOS/Linux:
```bash
./start.sh
```

#### On Windows:
```bash
start.bat
```

This will automatically:
- ✅ Install all dependencies
- ✅ Start the backend server on port 8080
- ✅ Start the frontend dev server on port 5173
- ✅ Open both in separate terminal windows

### Option 2: Manual Start

#### Start Backend:
```bash
cd booking_system_backend
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt
python server.py
```

#### Start Frontend (in a new terminal):
```bash
cd booking_system_frontend
npm install
npm run dev
```

## 🌐 Access the Application

Once started, access:

- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:8080/api
- **API Documentation**: http://localhost:8080/docs (Swagger UI)
- **MCP Endpoint**: http://localhost:8080/mcp (Model Context Protocol)
- **Health Check**: http://localhost:8080/ (returns server status)

## 📚 Documentation

### Backend
See [booking_system_backend/README.md](booking_system_backend/README.md) for:
- API endpoints documentation
- MCP tools reference
- Database schema
- Testing instructions

### Frontend
See [booking_system_frontend/README.md](booking_system_frontend/README.md) for:
- Component documentation
- Styling guide
- Build instructions
- Deployment options

## 🎯 User Guide

### Booking a Flight

1. **Browse Flights** - Navigate to the Flights page to see all available routes
2. **Search & Filter** - Use the search bar to find specific destinations
3. **Sign In/Register** - Click "Book Now" and enter your name and email
4. **Confirm Booking** - Review flight details and confirm your reservation
5. **Manage Bookings** - View and cancel bookings from "My Bookings" page

### Demo Data

The system comes pre-seeded with:
- **10 Users** - Alice, Bob, Charlie, Diana, Eve, Frank, Grace, Heidi, Ivan, Judy
- **10 Flights** - Routes between Earth, Mars, Moon, Venus, Jupiter, Europa, Pluto
- **20 Sample Bookings** - Various booking statuses

## 🛠️ Technology Stack

### Backend
- **FastAPI** - Modern Python web framework
- **SQLAlchemy** - ORM for database operations
- **Pydantic** - Data validation
- **FastMCP** - MCP protocol support
- **SQLite** - Lightweight database
- **Uvicorn** - ASGI server

### Frontend
- **React 18** - UI library
- **TypeScript** - Type safety
- **Vite** - Build tool
- **Tailwind CSS** - Styling
- **Framer Motion** - Animations
- **React Router** - Routing
- **Axios** - HTTP client
- **React Hot Toast** - Notifications

## 🧪 Testing

### Backend Tests

Run all tests:
```bash
cd booking_system_backend
pytest
```

Run with verbose output:
```bash
cd booking_system_backend
pytest -v
```

Run specific test file:
```bash
cd booking_system_backend
pytest tests/test_services.py
```

Run single test:
```bash
cd booking_system_backend
pytest tests/test_services.py::TestFlightService::test_list_flights_empty
```

### Frontend Tests

Build test (validates TypeScript compilation):
```bash
cd booking_system_frontend
npm run build
```

Lint check:
```bash
cd booking_system_frontend
npm run lint
```

## 📦 Production Deployment

### Backend
```bash
cd booking_system_backend
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8080
```

### Frontend
```bash
cd booking_system_frontend
npm run build
# Deploy the 'dist' folder to your hosting service
```

### Docker Support
Both backend and frontend include Dockerfiles for containerized deployment.

## 🎨 Customization

### Change API URL
Edit `booking_system_frontend/.env`:
```env
VITE_API_URL=https://your-api-url.com
```

### Modify Theme Colors
Edit `booking_system_frontend/tailwind.config.js`:
```js
colors: {
  'cosmic-purple': '#6366F1',
  'nebula-pink': '#EC4899',
  // Add your colors
}
```

## 🔧 Development Notes

### Backend Architecture

- **Service Layer Pattern**: Business logic separated from transport layer
- **Dual Protocol**: Same services exposed via REST and MCP
- **Error Handling**: Services return `Union[Result, ErrorResponse]` (never raise exceptions)
- **Database Sessions**:
  - REST endpoints use `get_db()` dependency injection
  - MCP tools use `SessionLocal()` directly
- **Critical Ordering**: MCP server must be created BEFORE FastAPI app in server.py

### Frontend Architecture

- **User Persistence**: User data stored in localStorage with key `'galaxium_user'`
- **API Integration**: Uses Axios with `import.meta.env.VITE_API_URL` (Vite-specific)
- **Error Detection**: Check `response.success === false` for API errors
- **Type Safety**: All types use snake_case to match Python backend

### Testing Patterns

- **Backend tests must run from backend directory**: `cd booking_system_backend && pytest`
- **In-memory SQLite**: Tests use `:memory:` database with StaticPool
- **Monkeypatching**: Tests patch both `db.SessionLocal` and `server.SessionLocal`
- **Seed disabled**: `seed()` is monkeypatched to prevent test data pollution

## 🐛 Troubleshooting

### Backend won't start
- Ensure Python 3.8+ is installed: `python --version`
- Check if port 8080 is available: `netstat -an | grep 8080` (Unix) or `netstat -an | findstr 8080` (Windows)
- Verify all dependencies are installed: `pip install -r requirements.txt`
- Check for database file permissions in `booking_system_backend/`

### Frontend won't start
- Ensure Node.js 18+ is installed: `node --version`
- Check if port 5173 is available
- Delete `node_modules` and reinstall: `rm -rf node_modules && npm install`
- Clear Vite cache: `rm -rf node_modules/.vite`

### Connection Issues
- Verify backend is running on http://localhost:8080
- Check CORS settings in backend (should allow http://localhost:5173)
- Ensure `.env` file exists in frontend with correct API URL
- Check browser console for detailed error messages

### Test Failures
- Backend tests must run from `booking_system_backend` directory
- Ensure no other instance of the server is running
- Clear any existing `galaxium.db` file before running tests

## 🔗 Related Documentation

- **Backend Details**: [booking_system_backend/README.md](booking_system_backend/README.md)
- **Frontend Details**: [booking_system_frontend/README.md](booking_system_frontend/README.md)
- **Agent Guidelines**: [AGENTS.md](AGENTS.md)
- **Implementation Plans**: [plans/](plans/)

## 📄 License

This project is part of the Galaxium Travels booking system.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📧 Support

For issues or questions:
- Check the documentation in each component's README
- Review the troubleshooting section above
- Open an issue on GitHub

---

**Built with ❤️ for space travelers** 🚀✨

*Explore the cosmos, one booking at a time!*