# README Update Summary

**Date**: 2026-05-25T18:02:20Z

## Changes Made

Updated the main README.md with the following improvements:

### 1. Enhanced Project Structure
- Added detailed directory tree showing all major components
- Included service layer breakdown (booking.py, flight.py, user.py)
- Added test file structure
- Included .bob/ and plans/ directories

### 2. Improved Access URLs
- Clarified API base path is `/api`
- Added health check endpoint documentation
- Specified Swagger UI for API docs
- Clarified MCP endpoint purpose

### 3. Expanded Testing Section
- Added multiple pytest command examples
- Included verbose output option
- Added single test execution example
- Added frontend lint command

### 4. New Development Notes Section
- Backend architecture patterns (service layer, dual protocol, error handling)
- Frontend architecture patterns (localStorage, API integration, type safety)
- Testing patterns (directory requirements, in-memory SQLite, monkeypatching)
- Critical implementation details from AGENTS.md

### 5. Enhanced Troubleshooting
- Added port checking commands for both Unix and Windows
- Added database file permissions check
- Added Vite cache clearing
- Added test-specific troubleshooting
- More detailed connection issue debugging

### 6. Added Related Documentation Section
- Links to backend README
- Links to frontend README
- Links to AGENTS.md
- Links to implementation plans

## Rationale

The updates make the README more comprehensive and useful for:
- New developers onboarding to the project
- Debugging common issues
- Understanding the architecture
- Running tests effectively
- Following best practices discovered in AGENTS.md