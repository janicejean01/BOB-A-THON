# AGENTS.md

This file provides guidance to agents when working with code in this repository.

## Project Structure (Non-Obvious)

- **Dual Protocol Backend**: Backend serves BOTH REST API (FastAPI) AND MCP protocol (FastMCP) on same server
- **MCP must be created BEFORE FastAPI app** - Critical ordering in server.py for lifespan combination
- **MCP tools use SessionLocal() directly** - They create/close their own DB sessions (not using FastAPI dependency injection)
- **REST endpoints use get_db() dependency** - Different pattern from MCP tools
- **Services return Union types** - All service functions return `Result | ErrorResponse`, must check type before using

## Testing (Non-Obvious)

- **Backend tests must run from backend directory**: `cd booking_system_backend && pytest`
- **Tests use sys.path.insert(0)** - Required in conftest.py and test files to import from parent
- **In-memory SQLite with StaticPool** - Tests use `:memory:` database with StaticPool for thread safety
- **Monkeypatch SessionLocal** - Tests patch both `db.SessionLocal` and `server.SessionLocal` separately
- **seed() is disabled in tests** - Monkeypatched to lambda: None to prevent data pollution

## Backend Patterns (Non-Obvious)

- **Service layer returns ErrorResponse objects** - Not exceptions. Check `isinstance(result, ErrorResponse)` before using
- **MCP tools convert ErrorResponse to Exception** - They raise Exception(result.details or result.error)
- **Booking requires name validation** - book_flight checks both user_id AND name match (not just user_id)
- **Seats are decremented immediately** - No transaction rollback on booking failure after seat decrement
- **Status is string, not enum** - "booked", "cancelled", "completed" are plain strings in DB

## Frontend Patterns (Non-Obvious)

- **User stored in localStorage** - Key is 'galaxium_user', persists across sessions
- **API base URL from env** - Uses `import.meta.env.VITE_API_URL` (Vite-specific, not process.env)
- **Error responses have success: false** - Check `response.success === false` to detect errors
- **Types use snake_case** - API types match Python backend (flight_id, user_id, not flightId)
- **Frontend must run from frontend directory**: `cd booking_system_frontend && npm run dev`

## Commands

**Backend:**
- Run server: `cd booking_system_backend && python server.py` (port 8080)
- Run tests: `cd booking_system_backend && pytest`
- Single test: `cd booking_system_backend && pytest tests/test_services.py::TestFlightService::test_list_flights_empty`

**Frontend:**
- Dev server: `cd booking_system_frontend && npm run dev` (port 5173)
- Build: `cd booking_system_frontend && npm run build`
- Lint: `cd booking_system_frontend && npm run lint`

**Both:**
- Quick start: `./start.sh` (Unix/Mac) or `start.bat` (Windows) from project root